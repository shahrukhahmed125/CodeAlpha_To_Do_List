function add(){
    var text=document.getElementById('in').value;
    var par=document.getElementById('p').innerHTML;
    var concat=par+'<br>'+text;
    document.getElementById('p').innerHTML=concat;
}